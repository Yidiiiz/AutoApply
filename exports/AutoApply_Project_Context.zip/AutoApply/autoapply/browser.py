import os
import re
import asyncio
import json
import time
from pathlib import Path
from urllib.parse import urlsplit

from .models import State
from .freshness import closed_status
from .security import SecurityDetector, classify_message, safe_url
from .retry import SiteError
from .cursor import get_cursor, CursorConfig


async def page_condition(page):
    security, _ = await SecurityDetector().detect(page)
    if security.blocking:
        return State.MANUAL_REVIEW, security.message
    text = (await page.locator("body").inner_text())[:150000]
    patterns = [
        (State.ALREADY_APPLIED, r"you (?:have )?already applied|you (?:have )?previously (?:applied|submitted)|an application (?:already )?exists|duplicate application"),
    ]
    for state, pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return state, match[0]
    if await page.locator('input[type="password"]:visible').count() or re.search(r"/(?:login|signin|sign-in|authwall)(?:[/?#]|$)", page.url, re.I):
        return State.AUTH_REQUIRED, "Sign-in requires the configured account; restore the persistent browser session"
    if closed_status(text):
        return State.CLOSED, "LISTING_CLOSED: explicit closure text"
    return None, ""


class Browser:
    def __init__(self, config):
        self.config, self.context, self.playwright = config, None, None
        self.start_lock = asyncio.Lock()
        self.observations = {}

    async def start(self):
        async with self.start_lock:
            await self._start()

    async def _start(self):
        if self.context:
            return
        from playwright.async_api import async_playwright
        local_browsers = self.config.root / "data/private/playwright"
        if local_browsers.exists():
            os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(local_browsers))
        self.reset_profile_zoom()
        self.playwright = await async_playwright().start()
        geometry = {"viewport":{"width":1440,"height":900}, "device_scale_factor":1} if self.config['browser']['headless'] else {"no_viewport":True}
        self.context = await self.playwright.chromium.launch_persistent_context(
            str(self.config.private / "browser_profile"), headless=self.config["browser"]["headless"],
            channel=self.config["browser"]["channel"], accept_downloads=False,
            **geometry, args=["--window-size=1460,1000"])
        self.context.set_default_timeout(self.config["browser"]["timeout_ms"])

    def reset_profile_zoom(self):
        """Reset only zoom preferences in AutoApply's own, not-yet-open profile."""
        path = self.config.private / 'browser_profile/Default/Preferences'
        if not path.exists():
            return
        preferences = json.loads(path.read_text(encoding='utf-8'))
        partition = preferences.setdefault('partition', {})
        prior = {key:partition.get(key) for key in ('per_host_zoom_levels','default_zoom_level')}
        if prior['per_host_zoom_levels'] or prior['default_zoom_level']:
            backup = self.config.private / 'browser-zoom-before.json'
            backup.write_text(json.dumps(prior, indent=2), encoding='utf-8')
            partition.update(per_host_zoom_levels={}, default_zoom_level=0)
            temporary = path.with_suffix('.zoom-tmp')
            temporary.write_text(json.dumps(preferences), encoding='utf-8')
            temporary.replace(path)

    async def new_page(self):
        await self.start()
        page = await self.context.new_page()
        await self.ensure_desktop(page)
        self.observe(page)
        async def security_guard():
            result, _ = await SecurityDetector().detect(page, self.observation(page))
            return result.blocking
        get_cursor(page, CursorConfig(**self.config.data.get("cursor", {})), security_guard)
        return page

    async def ensure_desktop(self, page):
        before = await page.evaluate("() => ({width:innerWidth,height:innerHeight,outerWidth,outerHeight,scale:devicePixelRatio})")
        available = await page.evaluate("() => ({width:screen.availWidth,height:screen.availHeight})")
        if not self.config["browser"]["headless"]:
            width, height = min(1460, available['width']), min(1000, available['height'])
            session = await self.context.new_cdp_session(page)
            try:
                window = await session.send("Browser.getWindowForTarget")
                await session.send("Browser.setWindowBounds", {"windowId": window["windowId"], "bounds": {"windowState": "normal"}})
                await session.send("Browser.setWindowBounds", {"windowId": window["windowId"], "bounds": {"width":width,"height":height}})
                await page.set_viewport_size({"width": max(800,width-20), "height":max(500,height-100)})
            finally:
                await session.detach()
        else:
            await page.set_viewport_size({"width": 1440, "height": 900})
        after = await page.evaluate("() => ({width:innerWidth,height:innerHeight,outerWidth,outerHeight,scale:devicePixelRatio})")
        self.viewport_diagnostics = {"before":before,"after":after}
        return self.viewport_diagnostics

    def observe(self, page):
        if page in self.observations:
            return
        data = self.observations[page] = {"status": None, "dialogs": [], "messages": [], "dialog_open": False, "network_error": False, "pending_uploads":{}, "upload_failed":False, "http_failures": []}
        from .uploads import UploadTracker
        tracker = page._autoapply_uploads = UploadTracker()
        def request_started(request):
            tracker.started(request)
            if request in tracker.requests:
                data['pending_uploads'][id(request)] = True
        def request_finished(request):
            tracker.finished(request)
            data['pending_uploads'].pop(id(request), None)
        async def hold_cursor():
            cursor = getattr(page, "_autoapply_cursor", None)
            if cursor:
                try:
                    await cursor.enter_manual_mode()
                except Exception:
                    # The hold remains active even when browser input cleanup fails.
                    cursor._event("cleanup_failed")
        async def response(response):
            request = response.request
            if response.status >= 400:
                try:
                    frame_url = safe_url(request.frame.url)
                    main_frame = request.frame == page.main_frame
                except Exception:
                    frame_url, main_frame = "", False
                data['http_failures'].append(dict(url=safe_url(response.url),
                    method=request.method, resource_type=request.resource_type,
                    status=response.status, frame_url=frame_url, main_frame=main_frame))
                data['http_failures'] = data['http_failures'][-50:]
            await tracker.response(response)
            if id(request) in data['pending_uploads'] and response.status >= 400:
                data['upload_failed'] = True
            relevant = request.resource_type in {"document", "xhr", "fetch"}
            # A read-only background authentication probe is diagnostic evidence,
            # not proof that the application document or submission was rejected.
            # Keep DOM/error-message detection and document/write failures blocking.
            background_auth_probe = (response.status == 401 and request.method == 'GET'
                                     and request.resource_type in {'xhr', 'fetch'})
            if relevant and not background_auth_probe and (response.status >= 400 or request.resource_type == "document" and request.frame == page.main_frame):
                data["status"] = response.status
            # Inspect only bounded, first-party JSON error messages. Never store bodies,
            # headers, request payloads, credentials or challenge-response fields.
            if request.resource_type not in {"xhr", "fetch"} or urlsplit(response.url).hostname != urlsplit(page.url).hostname:
                return
            try:
                headers = response.headers
                length = int(headers.get("content-length", "0"))
                if "application/json" not in headers.get("content-type", "") or not 0 < length <= 65536:
                    return
                payload = await response.json()
                if isinstance(payload, dict):
                    for key in ("error", "message", "error_description"):
                        value = payload.get(key)
                        if isinstance(value, str):
                            detected = classify_message(value)
                            if detected.blocking:
                                data["messages"].append(detected.message)
                                data["messages"] = data["messages"][-10:]
                                await hold_cursor()
            except (ValueError, TypeError):
                pass
            except Exception:
                # Navigation may dispose a response; DOM/HTTP detection still applies.
                pass
        def failed(request):
            tracker.failed(request)
            if request.failure == 'net::ERR_NETWORK_ACCESS_DENIED':
                data['execution_blocked'] = True
            if id(request) in data['pending_uploads']:
                data['upload_failed'] = True
            data['pending_uploads'].pop(id(request), None)
            if request.resource_type in {"document", "xhr", "fetch"}:
                data["network_error"] = True
        async def dialog(dialog):
            # Keep the dialog available for the user; persist only classified security text.
            result = classify_message(dialog.message, prominent=True)
            data["dialogs"].append(result.message or "Unresolved browser dialog")
            data["dialog_open"] = True
            await hold_cursor()
        page.on("response", response)
        page.on('request',request_started)
        page.on('requestfinished',request_finished)
        page.on("requestfailed", failed)
        page.on("dialog", dialog)
        page.on("close", lambda: self.observations.pop(page, None))

    def observation(self, page):
        return self.observations.get(page, {})

    def reset_observation(self, page):
        data = self.observation(page)
        data.update(status=None, dialogs=[], messages=[], dialog_open=False, network_error=False)

    async def uploads_ready(self, page, controls, timeout_seconds=180):
        from .uploads import wait_for_uploads
        return await wait_for_uploads(self, page, controls, timeout_seconds)

    async def change_marker(self, page):
        return await page.evaluate("""() => {
          if (!window.__autoapplyChanges) {
            window.__autoapplyChanges = {count:0};
            new MutationObserver(() => window.__autoapplyChanges.count++).observe(document.documentElement,
              {subtree:true,childList:true,characterData:true,attributes:true});
          }
          return window.__autoapplyChanges.count;
        }""")

    async def wait_for_change(self, page, marker, timeout_ms):
        from playwright.async_api import TimeoutError as PlaywrightTimeout
        try:
            await page.wait_for_function("n => !window.__autoapplyChanges || window.__autoapplyChanges.count !== n",
                                         arg=marker, timeout=max(1, timeout_ms))
        except PlaywrightTimeout:
            pass

    async def navigate(self, page, url):
        from .jobs import canonical_url
        canonical_url(url)
        response = await page.goto(url, wait_until="domcontentloaded")
        await self.normalize_zoom(page)
        if response and response.status in {404, 410}:
            condition, evidence = await page_condition(page)
            if condition in {State.MANUAL_REVIEW, State.AUTH_REQUIRED}:
                return condition, evidence
            return State.CLOSED, f"HTTP {response.status}"
        if response and response.status in {401, 403, 429}:
            return State.MANUAL_REVIEW, f"HTTP {response.status}; authentication, security or rate limit"
        if response and response.status >= 500:
            raise SiteError(f"Transient HTTP {response.status}")
        return await page_condition(page)

    async def normalize_zoom(self, page):
        # Persistent Chromium profiles retain per-site browser zoom. A fixed
        # viewport alone cannot correct a site saved at 33% zoom.
        before = await page.evaluate("() => ({width:innerWidth,height:innerHeight,scale:devicePixelRatio})")
        after = await page.evaluate("() => ({width:innerWidth,height:innerHeight,scale:devicePixelRatio})")
        self.zoom_diagnostics = {"before":before,"after":after}
        if page.viewport_size and abs(after['width']-page.viewport_size['width']) > 3:
            from .scrolling import NavigationError
            raise NavigationError('Browser zoom changed during the session; restore 100% zoom before continuing')
        return self.zoom_diagnostics

    async def screenshot(self, page, folder, name):
        Path(folder).mkdir(parents=True, exist_ok=True)
        masks = [frame.locator('input,textarea,select,[contenteditable],video,canvas,iframe,img') for frame in page.frames]
        await page.screenshot(path=str(Path(folder) / (name + ".png")), full_page=True, mask=masks, timeout=5000)

    async def close(self):
        if self.context:
            for page in self.context.pages:
                cursor = getattr(page, "_autoapply_cursor", None)
                if cursor:
                    try:
                        await cursor.cancel()
                    except Exception:
                        pass  # Closing the context below also destroys its input state.
            await self.context.close()
        if self.playwright:
            await self.playwright.stop()
        self.context = self.playwright = None
