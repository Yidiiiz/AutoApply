"""Upload lifecycle evidence. Never retain payloads, headers, or signed URLs."""
import asyncio
import re
import time
from urllib.parse import parse_qs, urlsplit

from .models import now


def operation(request):
    url = urlsplit(request.url)
    query = parse_qs(url.query)
    name = query.get('op', query.get('operationName', ['']))[0]
    if not name and url.path.endswith('/non-user-graphql'):
        try:
            payload = request.post_data_json
            if isinstance(payload, dict):
                name = payload.get('operationName', '')
        except Exception:  # noqa: BLE001 -- browser may dispose request during navigation
            name = ""  # Multipart bodies are deliberately never inspected.
    return name if isinstance(name, str) and re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,100}', name) else ''


class UploadTracker:
    def __init__(self):
        self.requests = {}
        self.events = []
        self.selected = 0
        self.result = {}

    def emit(self, kind, **detail):
        self.events.append(dict(kind=kind, at=now(), **detail))

    def select(self):
        self.selected += 1
        self.emit('UPLOAD_FILE_SELECTED', selection=self.selected)

    def started(self, request):
        url = urlsplit(request.url)
        op = operation(request)
        metadata = op == 'ApiSetFormValueToFile'
        greenhouse = (self.selected > 0 and getattr(self, 'greenhouse', False)
                      and request.method == 'POST'
                      and bool(re.fullmatch(r'[a-z0-9.-]+\.s3(?:[.-][a-z0-9-]+)?\.amazonaws\.com', url.hostname or '')))
        if request.method not in {'POST', 'PUT'} or not (metadata or greenhouse or re.search(r'upload|presigned', url.path, re.IGNORECASE)):
            return
        if greenhouse:
            op = 'GreenhouseS3Upload'
        # Only a known public API path is retained verbatim. Object-store paths
        # can contain private identifiers, even when the query string is removed.
        path = url.path if url.path in {'/api/non-user-graphql', '/upload'} else '/[upload-path]'
        item = dict(method=request.method, domain=url.hostname, path=path,  # noqa: C408
                    operation=op, started_at=now(), ended_at=None, status=None,
                    completed=False, failed=False, inspected=not metadata,
                    metadata=metadata, metadata_confirmed=False, selection=self.selected)
        self.requests[request] = item
        self.emit('UPLOAD_REQUEST_STARTED', **item)
        self.emit('UPLOAD_REQUEST_OPERATION', operation=op)

    async def response(self, response):
        item = self.requests.get(response.request)
        if item is None:
            return
        item['status'] = response.status
        item['failed'] = not 200 <= response.status < 300
        self.emit('UPLOAD_RESPONSE_STATUS', status=response.status, operation=item['operation'])
        if item['metadata'] and not item['failed']:
            try:
                payload = await response.json()
                # GraphQL 200 with errors is a failed write. Store only shape
                # verdicts; response values may contain applicant/file data.
                data = payload.get('data')
                values = list(data.values()) if isinstance(data, dict) else []
                rejected = any(isinstance(v, dict) and (v.get('success') is False or v.get('error')) for v in values)
                item['failed'] = bool(payload.get('errors') or payload.get('error') or rejected)
                item['metadata_confirmed'] = any(v is not None and v is not False for v in values) and not item['failed']
                if item['failed']:
                    item['failure_code'] = 'metadata_write_rejected'
            except Exception:  # noqa: BLE001 -- response disposal must fail closed
                item['metadata_confirmed'] = False
            item['inspected'] = True
            self.emit('UPLOAD_METADATA_CONFIRMED', value=item['metadata_confirmed'])

    def finished(self, request):
        item = self.requests.get(request)
        if item:
            item.update(completed=True, ended_at=now())
            self.emit('UPLOAD_REQUEST_COMPLETED', operation=item['operation'], status=item['status'])

    def failed(self, request):
        item = self.requests.get(request)
        if item:
            failure = getattr(request, 'failure', '') or ''
            code = re.search(r'net::ERR_[A-Z_]+', failure)
            item.update(failed=True, completed=False, ended_at=now(),
                        failure_code=code[0] if code else 'transport_failure')
            self.emit('UPLOAD_REQUEST_FAILED', operation=item['operation'], failure_code=item['failure_code'])

    def verdict(self, ui, *, ashby, expired=False, legacy_pending=False):
        records = list(self.requests.values())
        active = any(not r['ended_at'] or not r['inspected'] for r in records)
        failed = any(r['failed'] for r in records)
        metadata = [r for r in records if r['metadata'] and r['completed'] and r['metadata_confirmed']]
        metadata_ok = bool(metadata) and all(any(r['selection'] == n for r in metadata)
                                           for n in range(1, self.selected + 1))
        greenhouse_ok = not getattr(self, 'greenhouse', False) or (self.selected > 0 and all(
            any(r['operation'] == 'GreenhouseS3Upload' and r['selection'] == n
                and r['completed'] and r['status'] is not None and 200 <= r['status'] < 300
                and not r['failed'] for r in records) for n in range(1, self.selected + 1)))
        ready = (ui['attached'] and not ui['busy'] and not ui['disabled'] and not ui['warning']
                 and not active and not failed and not legacy_pending and greenhouse_ok
                 and (not ashby or metadata_ok and ui['replace_usable'] and ui['file_entry']))
        if ready:
            category = 'UPLOAD_READY'
        elif failed or not ui['attached']:
            category = 'UPLOAD_FAILED'
        elif expired and not records and ashby:
            category = 'UPLOAD_NOT_STARTED'
        elif expired and (active or records):
            category = 'UPLOAD_STALLED'
        else:
            category = 'UPLOAD_PENDING'
        self.result = dict(category=category, ready=bool(ready), file_selected=self.selected > 0,  # noqa: C408
                           request_started=bool(records), active=active, metadata_confirmed=metadata_ok,
                           ui=ui, requests=[dict(r) for r in records])
        return self.result


UI = r"""(e, expected) => {
 const visible=n=>!!(n.offsetWidth||n.offsetHeight||n.getClientRects().length);
 if(e.matches('.file-upload[data-autoapply-upload]')) {
   const entry=e.querySelector('.file-upload__filename');
   const remove=entry?.querySelector('button[aria-label="Remove file"]');
   const busy=[...e.querySelectorAll('[role=progressbar],[aria-busy=true]')].some(visible);
   const error=[...e.querySelectorAll('.helper-text--error,[role=alert]')].some(n=>visible(n)&&n.textContent.trim());
   const accepted=!!entry&&visible(entry)&&entry.textContent.trim()===expected.name&&!!remove&&!remove.disabled;
   return {attached:accepted,busy,disabled:!!remove?.disabled,warning:error,
     replace_visible:!!remove,replace_usable:!!remove&&!remove.disabled,file_entry:accepted};
 }
 let root=e.parentElement;
 for(let n=root,i=0;n&&i<6;n=n.parentElement,i++) {
   if(n.querySelectorAll('input[type=file]').length>1) break;
   root=n;
   if([...n.querySelectorAll('button')].some(b=>/^replace$/i.test((b.innerText||'').trim()))) break;
 }
 const replace=[...root.querySelectorAll('button')].filter(b=>visible(b)&&/^replace$/i.test((b.innerText||'').trim()));
 const disabled=b=>b.disabled||b.getAttribute('aria-disabled')==='true';
 return {attached:e.files?.length===1&&e.files[0].name===expected.name&&e.files[0].size===expected.size,
 busy:[...root.querySelectorAll('[aria-busy=true],[role=progressbar]')].some(visible),
 disabled:!!e.disabled||replace.some(disabled),replace_visible:replace.length>0,
 replace_usable:replace.some(b=>!disabled(b)),file_entry:root.innerText.includes(expected.name)};
}"""


async def wait_for_uploads(browser, page, controls, timeout_seconds):
    tracker = page._autoapply_uploads
    ashby = urlsplit(page.url).hostname == 'jobs.ashbyhq.com'
    deadline = time.monotonic() + timeout_seconds
    stable = None
    prior = None
    while True:
        ui = dict(attached=True, busy=False, disabled=False, warning=False,  # noqa: C408
                  replace_visible=True, replace_usable=True, file_entry=True)
        for field, name, size in controls.values():
            state = await field.evaluate(UI, {'name':name, 'size':size}) if await field.count() == 1 else {'attached':False}
            for key in ('attached', 'replace_visible', 'replace_usable', 'file_entry'):
                ui[key] &= bool(state.get(key))
            for key in ('busy', 'disabled', 'warning'):
                ui[key] |= bool(state.get(key))
        ui['warning'] |= await page.locator('body').evaluate(r"""e => [...e.querySelectorAll('[role=status],[role=alert],[aria-live],button')].some(n =>
          !!(n.offsetWidth||n.offsetHeight||n.getClientRects().length) && /uploading|updating your application/i.test(n.innerText||''))""")
        if ui != prior:
            for kind, key in [('UPLOAD_CONTROL_BUSY','busy'), ('UPLOAD_CONTROL_DISABLED','disabled'),
                              ('UPLOAD_REPLACE_VISIBLE','replace_visible'), ('UPLOAD_WARNING_VISIBLE','warning')]:
                tracker.emit(kind, value=ui[key])
            prior = dict(ui)
        expired = time.monotonic() >= deadline
        result = tracker.verdict(ui, ashby=ashby and bool(controls), expired=expired,
                                 legacy_pending=bool(browser.observation(page).get('pending_uploads')))
        browser.observation(page)['upload_result'] = result
        if result['ready']:
            if stable is None:
                stable = time.monotonic()
            if time.monotonic() - stable >= .5:
                tracker.emit('UPLOAD_READY', value=True)
                return True
        else:
            stable = None
        if expired or result['category'] == 'UPLOAD_FAILED':
            tracker.emit('UPLOAD_READY', value=False, category=result['category'])
            return False
        from .security import SecurityDetector
        security, _ = await SecurityDetector().detect(page, browser.observation(page))
        if security.blocking:
            return False
        await asyncio.sleep(.1)
