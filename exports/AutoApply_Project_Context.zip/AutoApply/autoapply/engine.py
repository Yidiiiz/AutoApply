from .cursor import click_element, get_cursor, Point
import asyncio
import hashlib
import json
import logging
import re
import time
from dataclasses import asdict
from datetime import date, datetime, timezone

from .ai import AIManager, ProviderUnavailable
from .answers import AnswerResolver, validate_answer, written_reuse, is_writing_question
from .applications import UnsupportedForm, adapter_for
from .archive import archive_application
from .browser import Browser, page_condition
from .control import Controller
from .jobs import eligibility
from .models import Answer, Question, State, now
from .sources import BrowserJobSource, scan_github
from .handoff import ManualHandoffManager, VERIFICATION
from .security import PreSubmitState, SubmissionClassifier, safe_url
from .retry import ErrorCategory, SiteError
from .scrolling import NavigationError
from .submission_probe import SubmissionProbe

log = logging.getLogger("autoapply")


class Engine:
    def __init__(self, config, db, browser=None):
        self.config, self.db = config, db
        self.browser = browser or Browser(config)
        self.ai = AIManager(config, db, self.browser)
        self.control = Controller(config, db, self.ai)
        self.resolver = AnswerResolver(config, db)
        self.next_application = 0.0
        self.stop_event = asyncio.Event()
        self.classifier = SubmissionClassifier()
        self.handoff = ManualHandoffManager(config, db, self.browser)
        self.processing_lock = asyncio.Lock()

    def interrupted(self, app_id):
        return self.stop_event.is_set() or self.db.setting("paused", False) or self.db.application(app_id)["status"] not in {"CHECKING", "APPLYING", "READY"}

    def request(self, app, q, reason):
        row = self.db.question(app["id"], q, reason)
        return row

    def hold(self, app_id, state, reason):
        evidence = {"confirmation_text": reason, "confirmation_url": safe_url(self.db.application(app_id)["canonical_url"])} if state == State.ALREADY_APPLIED else {}
        if state == State.CLOSED:
            self.db.mark_listing_closed(self.db.application(app_id)["job_id"])
            reason = "LISTING_CLOSED: " + reason
        self.db.transition(app_id, state, reason, **evidence)
        self.db.event(app_id, "hold", reason)

    def daily_count(self):
        # Count intent, not only confirmations: uncertain submissions also consume the ceiling.
        return self.db.one("SELECT count(*) n FROM applications WHERE substr(submit_intent_at,1,10)=?", (datetime.now(timezone.utc).date().isoformat(),))["n"]

    async def scan(self, force=False):
        self.db.cleanup_stale_listings()
        self.db._discovery_batch = True
        try:
            return await self._scan(force)
        finally:
            self.db._discovery_batch = False
            self.db.cleanup_stale_listings()

    async def _scan(self, force=False):
        counts = await scan_github(self.config, self.db, force)
        for name in ["linkedin", "handshake"]:
            if not self.config[name]["enabled"]:
                continue
            last = self.db.setting("scan:" + name, 0)
            if not force and time.time() - last < self.config["polling"][name + "_minutes"] * 60:
                continue
            self.db.set_setting("scan:" + name, time.time())
            try:
                source = BrowserJobSource(name, self.config, self.browser, self.db)
                listings = await source.discover()
                counts["pages_scanned"] += source.pages_scanned
                counts[name+"_stop_reason"] = source.stop_reason
                with self.db.ingest_batch():
                    for listing in listings:
                        _, created = self.db.ingest(listing, self.config)
                        counts["new"] += created
                        for metric,value in self.db.last_ingest_result.items():
                            counts[metric] = counts.get(metric,0) + value
            except Exception as exc:
                counts["errors"] += 1
                self.db.event(None, "source_error", name + ": " + type(exc).__name__)
                self.db.notify("source:" + name, {"message": f"{name} scan failed. Restore authentication or inspect source layout."})
        for row in self.db.rows("SELECT id FROM applications WHERE stage='' AND status IN ('INVALID','CLOSED','NEEDS_INPUT')"):
            archive_application(self.config, self.db, row["id"])
            self.db.execute("UPDATE applications SET stage='discovery' WHERE id=?", (row["id"],))
        for row in self.db.rows("SELECT DISTINCT q.application_id FROM questions q JOIN applications a ON a.id=q.application_id JOIN jobs j ON j.id=a.job_id WHERE j.listing_active=1 AND q.status='PENDING' AND a.status='NEEDS_INPUT'"):
            self.handoff.notify(row['application_id'], "Required information is pending")
        log.info("DISCOVERY COMPLETE: %s", counts)
        return counts

    async def inspect_security(self, app_id, page):
        result = await asyncio.wait_for(self.classifier.classify(page, self.browser.observation(page)), timeout=10)
        ats = self.classifier.ats(result.snapshot)
        s = result.security
        previous = self.db.application(app_id)
        ats_name = previous["ats_type"] if ats.provider in {"UNKNOWN", "custom"} and previous["ats_type"] not in {"UNKNOWN", "custom", "generic"} else ats.provider
        self.db.update_security(app_id, ats_type=ats_name, security_state=s.state,
            security_provider=s.provider if s.state != "NONE" else previous["security_provider"],
            security_type=s.type if s.state != "NONE" else previous["security_type"],
            last_http_status=s.http_status if s.http_status is not None else previous["last_http_status"],
            last_security_message=s.message or previous["last_security_message"], current_url=safe_url(page.url),
            previous_url=previous["current_url"] if previous["current_url"] != safe_url(page.url) else previous["previous_url"], diagnostics_at=now())
        if previous["ats_type"] != ats.provider:
            log.info("[ATS] Detected %s application=%s", ats.provider, app_id)
        if s.state != "NONE" and (s.state != previous["security_state"] or s.provider != previous["security_provider"]):
            log.info("[SECURITY] application=%s provider=%s state=%s", app_id, s.provider, s.state)
        return result

    async def security_gate(self, app_id, page):
        result = await self.inspect_security(app_id, page)
        if result.security.blocking:
            if result.security.state == "RATE_LIMITED" and not self.db.application(app_id)["submit_intent_at"]:
                self.db.fail(app_id, result.security.message, self.config["processing"]["max_retries"], ErrorCategory.RATE_LIMIT)
                self.db.update_security(app_id, application_state="RATE_LIMITED")
                await self.handoff.diagnostics(app_id, page)
                self.db.notify(f"rate:{app_id}:{now()}", {"application_id": app_id, "message": "Rate limited; bounded backoff applies only before submission."})
            else:
                await self.handoff.request(app_id, page, result.security.message, result.security.category)
            return True
        return False

    async def confirm(self, app_id, page, evidence):
        app = self.db.application(app_id)
        if not app["submission_confirmation_seen"]:
            self.db.transition(app_id, State.SUBMITTED, confirmation_text=evidence,
                confirmation_url=safe_url(page.url), submitted_at=now(), stage="confirmed")
            self.db.notify(f"submitted:{app_id}", {"application_id": app_id, "message": f"APPLICATION SUBMITTED - {app['company']} #{app_id}\n{app['title']}\nEmployer confirmation received."})
            log.info("[SUBMIT] Confirmation detected application=%s", app_id)

    async def post_submit(self, app_id, page, *, wait=True, probe=None):
        deadline = time.monotonic() + (self.config["application"]["confirmation_timeout_seconds"] if wait else 0)
        upload_race = False
        log.info("[SUBMIT] Waiting for confirmation application=%s", app_id)
        while True:
            marker = 0 if self.browser.observation(page).get("dialog_open") else await self.browser.change_marker(page)
            result = await self.inspect_security(app_id, page)
            self.db.update_security(app_id, url_after_submit=safe_url(page.url))
            if result.confirmation:
                if probe:
                    probe.confirmed(result.confirmation)
                await self.confirm(app_id, page, result.confirmation)
            app = self.db.application(app_id)
            if result.security.blocking:
                await self.handoff.request(app_id, page, result.security.message, result.security.category)
                return
            if app["submission_confirmation_seen"]:
                if time.monotonic() < deadline:
                    await self.browser.wait_for_change(page, marker, min(500, (deadline - time.monotonic()) * 1000))
                    continue
                if app["verification_state"] == "PENDING":
                    # Disappearance alone is not evidence of passing identity verification.
                    self.db.update_security(app_id, verification_state="UNKNOWN")
                folder = archive_application(self.config, self.db, app_id)
                await self.browser.screenshot(page, folder / "screenshots", "confirmation")
                return
            upload_race = upload_race or bool(re.search(r'updating your application|uploading files', result.snapshot['text'], re.I))
            if result.validation_error and not upload_race:
                await self.handoff.request(app_id, page, "Employer form validation failed after submit; correct fields manually. Automatic resubmission disabled.", ErrorCategory.FORM_VALIDATION_ERROR)
                self.db.update_security(app_id, application_state="FILLING")
                return
            if time.monotonic() >= deadline:
                if upload_race:
                    await self.handoff.request(app_id, page, 'Employer reported an upload/update in progress after the single Submit click. No second click attempted.', ErrorCategory.UPLOAD_RACE_DETECTED)
                    return
                if probe:
                    await probe.sample()
                    if not probe.has_effect:
                        reason = ('Production click returned without observable form, navigation, or network effect. '
                                  + ('Trusted click reached the button, but no application response was observed.' if probe.data['delivered'] else
                                     'No trusted click reaching the submit button was observed; inspect submit telemetry.'))
                        await self.handoff.request(app_id, page, reason, ErrorCategory.SUBMIT_CLICK_NOT_DELIVERED)
                        return
                await self.handoff.request(app_id, page, "Submit was clicked but no affirmative confirmation was found; check the preserved page and employer history.", unknown=True)
                return
            # Wait for DOM changes, with a bounded wakeup to inspect response metadata.
            await self.browser.wait_for_change(page, marker, min(500, (deadline - time.monotonic()) * 1000))

    async def process_one(self, application_id=None):
        async with self.processing_lock:
            target = self.db.setting("controlled_application_id")
            if target is not None and application_id != target:
                return False
            if self.handoff.pages:
                return False
            return await self._process_one(application_id)

    async def _process_one(self, application_id=None, preserved_page=None):
        if application_id is not None and self.db.automation_retired(application_id):
            return False
        if self.db.setting("paused", False) or self.stop_event.is_set():
            return False
        if self.daily_count() >= self.config["processing"]["max_applications_per_day"]:
            self.db.notify("daily-cap:" + date.today().isoformat(), {"message": "Daily application ceiling reached; new submissions resume next UTC day."})
            return False
        app = self.db.application(application_id) if preserved_page else self.db.claim(application_id)
        if not app:
            return False
        page = preserved_page
        probe = None
        try:
            app_id = app["id"]
            if not self.db.guard_listing(app_id):
                return True
            page = page or await self.browser.new_page()
            if preserved_page:
                state, evidence = await page_condition(page)
            else:
                state, evidence = await self.browser.navigate(page, app["canonical_url"])
            if await self.security_gate(app_id, page):
                return True
            if state:
                if state in {State.MANUAL_REVIEW, State.AUTH_REQUIRED}:
                    await self.handoff.request(app_id, page, evidence, ErrorCategory.AUTH_REQUIRED if state == State.AUTH_REQUIRED else ErrorCategory.UNKNOWN_SECURITY_FAILURE)
                else:
                    self.hold(app_id, state, evidence)
                return True
            if not self.db.bind_url(app_id, page.url):
                return True
            adapter = adapter_for(page)
            if app["ats"] in {"linkedin", "handshake"}:
                external = await adapter.external_application()
                if external:
                    state, evidence = await self.browser.navigate(page, external)
                    if await self.security_gate(app_id, page):
                        return True
                    if state:
                        # The internal flow remains available on an explicit retry.
                        if state in {State.MANUAL_REVIEW, State.AUTH_REQUIRED}:
                            await self.handoff.request(app_id, page, evidence, ErrorCategory.AUTH_REQUIRED if state == State.AUTH_REQUIRED else ErrorCategory.UNKNOWN_SECURITY_FAILURE)
                        else:
                            self.hold(app_id, state, evidence)
                        return True
                    if not self.db.bind_url(app_id, page.url):
                        return True
                    adapter = adapter_for(page)
            self.db.execute("UPDATE jobs SET last_checked_at=? WHERE id=?", (now(),app["job_id"]))
            listing = await adapter.inspect()
            self.db.execute("UPDATE jobs SET description=? WHERE id=?", (listing["description"], app["job_id"]))
            if listing["location"]:
                self.db.execute("UPDATE jobs SET location=? WHERE id=?", (listing["location"], app["job_id"]))
            for key in ["company", "title"]:
                if listing[key] and (key == "title" or app[key] == "Unknown employer"):
                    self.db.execute(f"UPDATE jobs SET {key}=? WHERE id=?", (listing[key], app["job_id"]))
            app = self.db.application(app_id)
            check = eligibility(app, self.config.profile)
            self.db.execute("UPDATE jobs SET eligibility_json=? WHERE id=?", (json.dumps(asdict(check)), app["job_id"]))
            for match in check.standing_matches:
                self.db.event(app_id, "standing_eligibility_answer", json.dumps(match))
            if check.eligible is False:
                self.hold(app_id, State.INELIGIBLE, "; ".join(check.reasons))
                return True
            if check.eligible is None and not app["eligibility_override"]:
                q = Question("eligibility", "Have you verified that you meet all the listed requirements and this is a U.S. opportunity?", "radio", True, ["Yes", "No"], scope=f"application:{app_id}")
                self.request(app, q, "\n".join(check.uncertainties))
                self.hold(app_id, State.NEEDS_INPUT, "Eligibility requires verification")
                await self.handoff.request(app_id, page, "Eligibility requires verification", ErrorCategory.INPUT_REQUIRED)
                return True
            if self.interrupted(app_id):
                return True
            self.db.transition(app_id, State.APPLYING, stage="opening form")
            if not preserved_page or app["stage"] == "checking":
                await adapter.begin()
            if await self.security_gate(app_id, page):
                return True
            existing_confirmation = await adapter.verify_submission()
            if existing_confirmation:
                self.hold(app_id, State.ALREADY_APPLIED, "Existing confirmation was visible before AutoApply submitted: " + existing_confirmation)
                return True
            seen_pages = set()
            saved_answers = {r['field_key']: r for r in self.db.rows(
                "SELECT * FROM questions WHERE application_id=? AND status='ANSWERED' AND field_type='combobox'", (app_id,))}
            adapter.answer_hints = saved_answers
            for step in range(self.config["application"]["max_pages"]):
                if self.interrupted(app_id):
                    return True
                state, evidence = await page_condition(page)
                if await self.security_gate(app_id, page):
                    return True
                if state:
                    if state in {State.MANUAL_REVIEW, State.AUTH_REQUIRED}:
                        await self.handoff.request(app_id, page, evidence, ErrorCategory.AUTH_REQUIRED if state == State.AUTH_REQUIRED else ErrorCategory.UNKNOWN_SECURITY_FAILURE)
                    else:
                        self.hold(app_id, state, evidence)
                    return True
                self.db.execute("UPDATE applications SET stage=? WHERE id=?", (f"form page {step + 1}", app_id))
                questions = await adapter.get_questions(app)
                signature = tuple((q.key, q.label, tuple(q.options)) for q in questions)
                if signature in seen_pages:
                    raise UnsupportedForm("Form did not advance or repeats an indistinguishable step")
                seen_pages.add(signature)
                missing = False
                for q in questions:
                    if self.interrupted(app_id):
                        return True
                    if q.kind == "file":
                        row = self.db.question(app_id, q)
                        if re.search(r"resume|curriculum vitae|\bcv\b", q.label, re.I):
                            if not self.config.resume.exists() or not self.config.resume.read_bytes().startswith(b"%PDF-"):
                                # File contents remain local; Discord only asks whether setup is complete.
                                setup = Question("resume", "Place your current PDF at data/private/resumes/resume.pdf, then answer Ready", "text", True, scope=f"application:{app_id}")
                                self.request(app, setup, "The configured resume is missing or is not a PDF")
                                missing = True
                                continue
                            await adapter.upload_documents(q, self.config.resume)
                            digest = hashlib.sha256(self.config.resume.read_bytes()).hexdigest()
                            self.db.execute("UPDATE applications SET resume_used=?,resume_sha256=? WHERE id=?", (str(self.config.resume), digest, app_id))
                            self.db.save_answer(row["id"], Answer("resume.pdf", "verified_document"))
                        elif q.required:
                            self.request(app, q, "A required document needs manual preparation and upload")
                            missing = True
                        else:
                            self.db.execute("UPDATE questions SET status='SKIPPED' WHERE id=?", (row["id"],))
                        continue
                    row = self.db.question(app_id, q)
                    if row["status"] == "SKIPPED" and not q.required and not is_writing_question(q):
                        continue
                    answer = None
                    previous_answer = saved_answers.get(q.key)
                    if q.kind == 'combobox' and previous_answer and all([
                        previous_answer['raw_question'] == q.label,
                        previous_answer['scope'] == q.scope,
                        previous_answer['required'] == int(q.required),
                        previous_answer['max_length'] == q.max_length,
                    ]):
                        candidate = Answer(json.loads(previous_answer['answer']), previous_answer['answer_source'], previous_answer['confidence'])
                        if candidate.value in q.options:
                            validate_answer(q, candidate.value)
                            answer = candidate
                    if row["status"] == "ANSWERED":
                        answer = Answer(json.loads(row["answer"]), row["answer_source"], row["confidence"])
                        try:
                            validate_answer(q, answer.value)
                        except ValueError:
                            answer = None
                    answer = answer or self.resolver.resolve(q, app)
                    if not answer and q.kind == "textarea":
                        answer = written_reuse(self.db, q, app)
                    if not answer and is_writing_question(q):
                        try:
                            answer = await self.ai.draft(q, app)
                        except ProviderUnavailable as exc:
                            reason = str(exc)
                            self.db.execute("UPDATE questions SET status='PENDING',reason=? WHERE id=?", (reason, row['id']))
                            self.request(app, q, reason)
                            missing = True
                            continue
                    if answer and answer.confidence >= self.config["application"]["min_confidence"]:
                        await adapter.answer_question(q, answer)
                        self.db.save_answer(row["id"], answer)
                    elif not q.required and (not q.value or q.kind == "checkbox" and q.value == "No"):
                        self.db.execute("UPDATE questions SET status='SKIPPED' WHERE id=?", (row["id"],))
                    else:
                        reason = "No sufficiently confident verified answer; existing prefilled values also require verification"
                        self.db.execute("UPDATE questions SET status='PENDING',reason=? WHERE id=?", (reason, row["id"]))
                        self.request(app, q, reason)
                        missing = True
                if missing:
                    self.hold(app_id, State.NEEDS_INPUT, "Application has unanswered questions")
                    await self.handoff.request(app_id, page, "Application has unanswered questions", ErrorCategory.INPUT_REQUIRED)
                    return True
                if await self.security_gate(app_id, page):
                    return True
                if not await self.check_uploads(app_id, page, adapter.uploads):
                    if not await self.security_gate(app_id, page):
                        await self.handoff.request(app_id, page, 'ATS upload readiness failed; see upload lifecycle evidence. No Submit click was attempted.', self.browser.observation(page).get('upload_result', {}).get('category', ErrorCategory.UPLOAD_PENDING))
                    return True
                self.db.event(app_id, 'ATS_UPLOAD_READY', json.dumps({
                    'tracked_uploads_complete':True, 'controls_not_busy':True,
                    'resume_selected':bool(self.db.application(app_id)['resume_sha256'])}))
                current_questions = await adapter.get_questions(app)
                if tuple((q.key, q.label, tuple(q.options)) for q in current_questions) != signature:
                    # Conditional fields must be answered and verified before submitting.
                    continue
                readiness, issues = await self.classifier.pre_submit(page, adapter, self.browser.observation(page))
                if readiness == PreSubmitState.INTERACTIVE_SECURITY_STEP:
                    await self.security_gate(app_id, page)
                    return True
                if readiness == PreSubmitState.VALIDATION_ERROR:
                    await self.handoff.request(app_id, page, "Validation failed: " + "; ".join(issues), ErrorCategory.FORM_VALIDATION_ERROR)
                    return True
                kind, button = await adapter.action()
                if not kind:
                    raise UnsupportedForm("No unique supported next/submit action was found")
                if kind == "next":
                    if self.interrupted(app_id):
                        return True
                    marker = await self.browser.change_marker(page)
                    await click_element(page, button)
                    await page.wait_for_load_state("domcontentloaded")
                    await self.browser.wait_for_change(page, marker, min(5000, self.config["browser"]["timeout_ms"]))
                    if await self.security_gate(app_id, page):
                        return True
                    continue
                if not questions:
                    raise UnsupportedForm("Refusing to submit a form without inspectable fields")
                if self.db.one("SELECT id FROM questions WHERE application_id=? AND status='PENDING'", (app_id,)):
                    self.hold(app_id, State.NEEDS_INPUT, "Unresolved questions remain from an earlier form step")
                    await self.handoff.request(app_id, page, "Unresolved questions remain from an earlier form step", ErrorCategory.INPUT_REQUIRED)
                    return True
                if not self.db.setting("auto_submit", self.config["application"]["auto_submit"]):
                    self.db.transition(app_id, State.READY, "Auto-submit is disabled; enable and retry to revalidate")
                    return True
                folder = archive_application(self.config, self.db, app_id)
                probe = SubmissionProbe(self.db, app_id, page, button)
                await probe.prepare()
                self.db.update_security(app_id, application_state="READY_TO_SUBMIT", url_before_submit=safe_url(page.url))
                folder = archive_application(self.config, self.db, app_id)
                pre_name = 'pre-submit-' + probe.key
                await self.browser.screenshot(page, folder / "screenshots", pre_name)
                probe.data['pre_submit_screenshot'] = pre_name + '.png'
                probe.save()
                if await self.security_gate(app_id, page):
                    return True
                # Re-check controls after the final await, immediately before durable submission intent.
                if self.interrupted(app_id) or not self.db.setting("auto_submit", self.config["application"]["auto_submit"]):
                    return True
                if self.daily_count() >= self.config["processing"]["max_applications_per_day"]:
                    self.hold(app_id, State.READY, "Daily ceiling reached before submission")
                    return True
                current = self.db.application(app_id)
                if current["resume_sha256"] and (not self.config.resume.exists() or hashlib.sha256(self.config.resume.read_bytes()).hexdigest() != current["resume_sha256"]):
                    raise UnsupportedForm("Resume changed after upload")
                # Inspect closure again after filling/screenshots, before any submit intent.
                state, evidence = await page_condition(page)
                if state:
                    if state in {State.MANUAL_REVIEW, State.AUTH_REQUIRED}:
                        await self.handoff.request(app_id, page, evidence)
                    else:
                        self.hold(app_id, state, evidence)
                    return True
                if self.interrupted(app_id) or not self.db.setting("auto_submit", self.config["application"]["auto_submit"]):
                    return True
                if not self.db.guard_listing(app_id):
                    return True
                readiness, issues = await self.classifier.pre_submit(page, adapter, self.browser.observation(page))
                if readiness == PreSubmitState.INTERACTIVE_SECURITY_STEP:
                    await self.security_gate(app_id, page)
                    return True
                if readiness == PreSubmitState.VALIDATION_ERROR:
                    await self.handoff.request(app_id, page, "Final validation failed: " + "; ".join(issues), ErrorCategory.FORM_VALIDATION_ERROR)
                    return True
                probe.data['validation'] = {
                    'all_pending_resolved':not bool(self.db.one("SELECT id FROM questions WHERE application_id=? AND status='PENDING'", (app_id,))),
                    'resume_verified':bool(self.db.application(app_id)['resume_sha256']),
                    'pre_submit_state':str(readiness), 'issues':issues,
                    'questions':[{'id':q['id'],'label':q['raw_question'],'required':bool(q['required']),
                                  'status':q['status'],'source':q['answer_source']}
                                 for q in self.db.rows('SELECT * FROM questions WHERE application_id=?',(app_id,))]}
                probe.record('PRE_SUBMIT_VALIDATION',probe.data['validation'])
                if not await self.check_uploads(app_id, page, adapter.uploads):
                    await self.handoff.request(app_id, page, 'ATS upload is not ready before Submit; see upload lifecycle evidence.', self.browser.observation(page).get('upload_result', {}).get('category', ErrorCategory.UPLOAD_PENDING))
                    return True
                await probe.arm()
                with self.db.transaction():
                    conflict = self.db.submission_conflict(app_id)
                    if conflict:
                        raise UnsupportedForm(f"Existing application {conflict['id']} is {conflict['status']}; check its history instead of submitting again")
                    self.db.transition(app_id, State.SUBMITTING, stage="submission intent", submit_intent_at=now())
                probe.intent()
                self.browser.reset_observation(page)
                log.info("[SUBMIT] Submission initiated application=%s", app_id)
                await probe.physical_click()
                immediate = await self.inspect_security(app_id, page)
                # Persist affirmative employer evidence before optional screenshot I/O.
                # A disappearing frame can invalidate a screenshot mask after success.
                if immediate.confirmation:
                    probe.confirmed(immediate.confirmation)
                    await self.confirm(app_id, page, immediate.confirmation)
                if immediate.security.state not in VERIFICATION and not self.browser.observation(page).get('dialog_open'):
                    folder = archive_application(self.config, self.db, app_id)
                    post_name = 'post-click-' + probe.key
                    await self.browser.screenshot(page, folder / 'screenshots', post_name)
                    probe.data['post_click_screenshot'] = post_name + '.png'
                    probe.save()
                if immediate.security.blocking:
                    await self.handoff.request(app_id, page, immediate.security.message, immediate.security.category)
                    return True
                await self.post_submit(app_id, page, probe=probe)
                return True
            raise UnsupportedForm("Application exceeded configured page limit")
        except NavigationError as exc:
            if page is None or page.is_closed() or not await self.security_gate(app['id'], page):
                await self.handoff.request(app["id"], page, str(exc), exc.category)
        except UnsupportedForm as exc:
            await self.handoff.request(app["id"], page, str(exc))
        except Exception as exc:
            # Exception messages can contain form values, tokens or sensitive URLs.
            reason = f"{type(exc).__name__} during {self.db.application(app['id'])['stage']}"
            current = self.db.application(app["id"])
            if current["submit_intent_at"]:
                import traceback
                self.db.event(app['id'], 'POST_SUBMIT_EXCEPTION', json.dumps({
                    'type': type(exc).__name__,
                    'frames': [{'file': f.filename.replace('\\', '/').rsplit('/', 1)[-1],
                                'line': f.lineno, 'function': f.name}
                               for f in traceback.extract_tb(exc.__traceback__)],
                    'confirmation_persisted': bool(current['submission_confirmation_seen'])}))
            if current["status"] != State.SUBMITTED:
                blocked = False
                if page and not page.is_closed():
                    try:
                        blocked = await self.security_gate(app["id"], page)
                    except Exception:
                        pass
                if not blocked:
                    if page and self.browser.observation(page).get('execution_blocked'):
                        await self.handoff.request(app['id'], page,
                            'Execution environment denied network access (ERR_NETWORK_ACCESS_DENIED)',
                            ErrorCategory.EXECUTION_APPROVAL_BLOCKED,
                            unknown=bool(current['submit_intent_at']))
                    elif current["submit_intent_at"]:
                        await self.handoff.request(app["id"], page, reason, unknown=True)
                    elif isinstance(exc, (TimeoutError, OSError, SiteError)) or type(exc).__name__ == "TimeoutError" or (page and self.browser.observation(page).get("network_error")):
                        category = ErrorCategory.SITE_ERROR if isinstance(exc, SiteError) else ErrorCategory.NETWORK_ERROR
                        self.db.fail(app["id"], reason, self.config["processing"]["max_retries"], category)
                    else:
                        await self.handoff.request(app["id"], page, reason)
                if self.db.application(app["id"])["status"] == "FAILED":
                    self.db.notify(f"failure:{app['id']}:{current['attempts']}", {"application_id": app["id"], "message": "APPLICATION FAILED: " + reason})
            log.warning("Application %s: %s", app["id"], reason)
        finally:
            if probe:
                try:
                    await probe.finish()
                except Exception as exc:
                    self.db.event(app['id'], 'submit_telemetry_unavailable', type(exc).__name__)
            current = self.db.application(app["id"])
            if (self.db.setting('controlled_application_id') == app['id'] and page
                    and not page.is_closed() and app['id'] not in self.handoff.pages
                    and (current['status'] not in {'SUBMITTED', 'CLOSED', 'INELIGIBLE', 'ALREADY_APPLIED'}
                         or current['manual_action_required'])):
                await self.handoff.request(app['id'], page,
                    'Controlled run stopped; preserve current page for inspection',
                    current['error_category'] or 'SUBMISSION_UNKNOWN',
                    unknown=bool(current['submit_intent_at']))
                current = self.db.application(app['id'])
            if current["status"] in {"CHECKING", "APPLYING"}:
                self.db.transition(app["id"], State.RETRY, "Processing paused before submission", retry_at=None)
            folder = archive_application(self.config, self.db, app["id"])
            if page and app["id"] not in self.handoff.pages:
                try:
                    if current["status"] in {"NEEDS_INPUT", "MANUAL_REVIEW", "AUTH_REQUIRED", "FAILED"}:
                        await self.browser.screenshot(page, folder / "screenshots", "attention")
                except Exception:
                    pass
                await page.close()
            self.next_application = time.monotonic() + self.config["application"]["delay_seconds"]
            log.info("Application %s: %s", app["id"], self.db.application(app["id"])["status"])
        return True

    async def check_uploads(self, app_id, page, controls):
        ready = await self.browser.uploads_ready(page, controls)
        tracker = getattr(page, '_autoapply_uploads', None)
        if tracker:
            for event in tracker.events:
                self.db.event(app_id, event['kind'], json.dumps(event))
            tracker.events.clear()
            self.db.set_setting(f'upload_result:{app_id}', tracker.result)
            self.db.event(app_id, 'UPLOAD_READINESS', json.dumps(tracker.result))
        return ready

    async def resume_manual(self, app_id, outcome=None, *, inspect_only=False, strict_session=False):
        if self.db.automation_retired(app_id):
            raise ValueError("User-reported submission permanently excludes this application from automation")
        async with self.processing_lock:
            target = self.db.setting("controlled_application_id")
            if target is not None and app_id != target:
                raise ValueError("Controlled run permits only the configured application")
            page = self.handoff.pages.get(app_id)
            if not inspect_only:
                self.control.resolve_known_pending(app_id)
            app = self.db.application(app_id)
            previous_security = app["security_state"]
            if page is None or page.is_closed():
                self.db.update_security(app_id, session_preserved=0)
                if (not strict_session and not inspect_only and app["error_category"] in {"INPUT_REQUIRED", "UPLOAD_PENDING", "UPLOAD_FAILED", "UPLOAD_NOT_STARTED", "UPLOAD_STALLED"} and app["manual_resume_allowed"]
                        and not app["submit_intent_at"] and not app["submission_confirmation_seen"]
                        and app["security_state"] in {"NONE", "PASSIVE_PROTECTION_DETECTED"}
                        and not self.db.one("SELECT id FROM questions WHERE application_id=? AND status='PENDING'", (app_id,))):
                    if self.db.setting("paused", False) or self.stop_event.is_set():
                        return False
                    if self.db.submission_conflict(app_id) or not self.db.guard_listing(app_id):
                        return False
                    self.handoff.release(app_id)
                    self.db.update_security(app_id, retry_allowed=1)
                    self.db.transition(app_id, State.RETRY, "Resolved durable input hold; reconstructing same application", retry_at=None)
                    return await self._process_one(app_id)
                if app["submission_confirmation_seen"] and outcome in {"PASSED", "FAILED", "SKIPPED"}:
                    self.db.update_security(app_id, verification_state=outcome)
                    self.db.event(app_id, "verification_user_report", outcome)
                    self.handoff.release(app_id)
                    archive_application(self.config, self.db, app_id)
                    self.db.notify(f"manual-result:{app_id}:{now()}", {"message": f"Application #{app_id} remains SUBMITTED. User reported verification {outcome}; live session unavailable."})
                    return True
                if app["submission_confirmation_seen"] and not app["manual_action_required"]:
                    self.handoff.release(app_id)
                    return True
                self.handoff.notify(app_id, "The preserved tab is unavailable; check employer history. No automatic restart or resubmission was performed.")
                return False
            self.browser.reset_observation(page)
            result = await self.inspect_security(app_id, page)
            if result.confirmation:
                await self.confirm(app_id, page, result.confirmation)
            app = self.db.application(app_id)
            if outcome in {"PASSED", "FAILED", "SKIPPED"}:
                self.db.update_security(app_id, verification_state=outcome)
                self.db.event(app_id, "verification_user_report", outcome)
            elif re.search(r"verification (?:was |has been )?(?:successful|complete|passed)|identity verified", result.snapshot["text"], re.I):
                self.db.update_security(app_id, verification_state="PASSED")
            elif re.search(r"verification (?:was |has )?failed|unable to verify (?:your )?identity", result.snapshot["text"], re.I):
                self.db.update_security(app_id, verification_state="FAILED")
            elif re.search(r"verification (?:was )?skipped", result.snapshot["text"], re.I):
                self.db.update_security(app_id, verification_state="SKIPPED")
            app = self.db.application(app_id)
            if result.security.blocking and not (app["submission_confirmation_seen"] and result.security.state in VERIFICATION and app["verification_state"] in {"PASSED", "FAILED", "SKIPPED"}):
                await self.handoff.request(app_id, page, result.security.message, result.security.category)
                return False
            if app["submission_confirmation_seen"]:
                if app["verification_state"] == "PENDING":
                    self.db.update_security(app_id, verification_state="UNKNOWN")
                # Keep the tab open for inspection, but it no longer blocks the worker.
                self.handoff.release(app_id)
                archive_application(self.config, self.db, app_id)
                self.db.notify(f"manual-result:{app_id}:{now()}", {"message": f"Application #{app_id} remains SUBMITTED. Verification: {self.db.application(app_id)['verification_state']}. No repeat submission."})
                log.info("[RESUME] Manual step completed application=%s; application confirmed", app_id)
                return True
            if app["submit_intent_at"]:
                await self.handoff.request(app_id, page, "Submission still unconfirmed after manual intervention. No repeat click; check employer history.", unknown=True)
                return False
            if inspect_only:
                return False
            if self.db.setting("paused", False) or self.stop_event.is_set():
                return False
            if self.daily_count() >= self.config["processing"]["max_applications_per_day"]:
                return False
            if not app["manual_resume_allowed"]:
                await self.handoff.request(app_id, page, "Security rejection requires manual completion. The banner disappeared, but automatic submission remains disabled.")
                return False
            if self.db.one("SELECT id FROM questions WHERE application_id=? AND status='PENDING'", (app_id,)):
                self.handoff.notify(app_id, "Pending factual questions must be answered before resuming.")
                return False
            await get_cursor(page).exit_manual_mode(Point(1, 1))
            # Reinspect/fill this exact page without navigation, resetting the form, or claiming another job.
            self.handoff.release(app_id)
            self.db.transition(app_id, State.APPLYING, "Manual step completed; revalidating preserved form")
            self.db.update_security(app_id, retry_allowed=1, verification_state="PASSED" if previous_security == "INTERACTIVE_CHALLENGE" else app["verification_state"])
            log.info("[RESUME] Revalidating preserved form application=%s", app_id)
            await self._process_one(app_id, preserved_page=page)
            return True

    async def service_manual_requests(self):
        for request in self.db.rows("SELECT * FROM manual_requests ORDER BY created_at"):
            app_id = request["application_id"]
            with self.db.transaction():
                deleted = self.db.execute("DELETE FROM manual_requests WHERE application_id=? AND action=? AND created_at=?",
                    (app_id, request["action"], request["created_at"]))
                if not deleted.rowcount:
                    continue
            command = None
            # Commands are consumed before page access. Failed commands require an
            # explicit new command; a crashed worker can never replay an action.
            try:
                if (request["action"] == "inspect" and self.db.setting("controlled_application_id") is None
                        and not self.db.automation_retired(app_id)
                        and self.db.application(app_id)["error_category"] == "INPUT_REQUIRED"):
                    # Preserve the existing ordinary-worker durable answer flow.
                    # Controlled workers never reconstruct a missing session.
                    await self.resume_manual(app_id)
                    continue
                command = json.loads(request["action"])
                token = self.handoff.sessions.get(app_id)
                if (self.db.automation_retired(app_id) or not token or command.get("token") != token
                        or self.db.setting(f"manual_ack:{command['id']}")
                        or command.get("action") not in {"inspect", "inspect-only", "PASSED", "FAILED", "SKIPPED"}):
                    continue
                self.db.set_setting(f"manual_ack:{command['id']}", "IN_PROGRESS")
                self.db.set_setting(f"manual_session:{app_id}", {"token": token,
                    "state": "MANUAL_INTERVENTION_COMPLETE", "busy": True})
                action = command["action"]
                await self.resume_manual(app_id, action if action in {"PASSED", "FAILED", "SKIPPED"} else None,
                    inspect_only=action == "inspect-only", strict_session=True)
                self.db.set_setting(f"manual_ack:{command['id']}", "ACKNOWLEDGED")
            except Exception as exc:
                if isinstance(command, dict) and command.get("id"):
                    self.db.set_setting(f"manual_ack:{command['id']}", "FAILED")
                self.db.event(app_id, "manual_inspection_error", type(exc).__name__)
            finally:
                token = self.handoff.sessions.get(app_id)
                if token:
                    self.db.set_setting(f"manual_session:{app_id}", {"token": token,
                        "state": "WAITING_FOR_MANUAL_INTERVENTION", "busy": False})

    async def wait_for_manual(self):
        # CLI work-once remains alive so Playwright does not dispose the populated form.
        while self.handoff.pages and not self.stop_event.is_set():
            await self.service_manual_requests()
            await asyncio.sleep(.5)

    async def close(self):
        # Called on explicit worker shutdown; a manual hold itself never calls close.
        for app_id in self.handoff.pages:
            self.db.update_security(app_id, session_preserved=0)
            self.db.event(app_id, "manual_session_ended", "Worker/browser shutdown; automatic retry remains disabled")
            archive_application(self.config, self.db, app_id)
        await self.browser.close()

    async def run(self):
        self.db.recover()
        bot = bot_task = None
        discord_available = not self.config["discord"]["enabled"]
        if self.config["discord"]["enabled"]:
            import os
            from .discord_bot import DiscordBot
            bot = DiscordBot(self.control)
            bot_task = asyncio.create_task(bot.start(os.environ["DISCORD_BOT_TOKEN"]))
        try:
            if bot:
                await bot.wait_for_delivery(bot_task)
                discord_available = True
            while not self.stop_event.is_set():
                if bot_task and bot_task.done():
                    if not self.handoff.pages:
                        await bot_task  # Invalid Discord credentials must be visible to the operator.
                        raise RuntimeError("Discord connection stopped")
                    try:
                        await bot_task
                    except Exception as exc:
                        self.db.event(None, "discord_disconnected", type(exc).__name__)
                    bot_task = None
                    discord_available = False
                    self.db.set_setting("paused", True)
                    log.error("[MANUAL] Discord stopped; browser retained. Use local resume-manual, then restart the worker to restore Discord.")
                await self.service_manual_requests()
                if discord_available and not self.db.setting("paused", False) and not self.handoff.pages:
                    try:
                        if self.db.setting("controlled_application_id") is None:
                            await self.scan()
                            if time.monotonic() >= self.next_application:
                                await self.process_one()
                    except Exception as exc:
                        log.warning("Worker cycle failed: %s", type(exc).__name__)
                        self.db.event(None, "worker_error", type(exc).__name__)
                try:
                    await asyncio.wait_for(self.stop_event.wait(), timeout=2)
                except TimeoutError:
                    pass
        finally:
            if bot:
                await bot.close()
            if bot_task:
                bot_task.cancel()
                await asyncio.gather(bot_task, return_exceptions=True)
            await self.close()
